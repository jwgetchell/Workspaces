Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.


' TODO: Review the values of the assembly attributes


<Assembly: AssemblyTitle("")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("IntersilPC image 02/27/09")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly:  AssemblyVersion("1.0.*")>



<Assembly: ComVisibleAttribute(True)> 
'<Assembly: GuidAttribute("C4AA70A2-8BF9-4c32-AC3A-8B9CD537FAF0")> 
<Assembly: GuidAttribute("8DBC9F53-84EA-4d86-8A86-B17F4E97F227")> 